package com.example.projetoteste;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private TextView status;
    private TextView descricao;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        descricao = findViewById(R.id.textDescricao); // Inicializa o novo TextView


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void calcularImc(View view) {
        TextInputEditText campoNome = findViewById(R.id.textInputNome);
        TextInputEditText campoPeso = findViewById(R.id.textInputPeso);
        TextInputEditText campoAltura = findViewById(R.id.textInputAltura);

        TextView resultado1 = findViewById(R.id.textResultado1);

        String nome = campoNome.getText().toString();
        String pesoStr = campoPeso.getText().toString();
        String alturaStr = campoAltura.getText().toString();

        if (pesoStr.isEmpty() || alturaStr.isEmpty()) {
            resultado1.setText("Preencha todos os campos");
            descricao.setText("");
            return;
        }

        // Convertemos os valores para Double
        double numPeso = Double.parseDouble(pesoStr);
        double numAltura = Double.parseDouble(alturaStr);

        // Verifique se a altura é zero para evitar divisão por zero
        if (numAltura <= 0) {
            resultado1.setText("Altura inválida");
            descricao.setText("");
            return;
        }

        // Calcula o IMC
        double numImc = numPeso / (numAltura * numAltura);

        // Formata o IMC para duas casas decimais
        DecimalFormat df = new DecimalFormat("##.##");
        String imc = df.format(numImc);

        resultado1.setText(imc);

        // Classificação do IMC usando switch
        String imcStatus;
        String imcDescricao;


        int faixaIMC;
        if (numImc < 18.5) {
            faixaIMC = 1;
        } else if (numImc >= 18.5 && numImc < 24.9) {
            faixaIMC = 2;
        } else if (numImc >= 25 && numImc < 29.9) {
            faixaIMC = 3;
        } else if (numImc >= 30 && numImc < 34.9) {
            faixaIMC = 4;
        } else {
            faixaIMC = 5;
        }

        switch (faixaIMC) {
            case 1:
                imcStatus = "Abaixo do peso";
                imcDescricao = "Você está abaixo do peso ideal. É importante manter uma alimentação equilibrada e consultar um nutricionista.";
                break;
            case 2:
                imcStatus = "Peso normal";
                imcDescricao = "Você está com o peso ideal. Continue mantendo uma dieta balanceada e um estilo de vida saudável.";
                break;
            case 3:
                imcStatus = "Sobrepeso";
                imcDescricao = "Você está com sobrepeso. Considere adotar hábitos saudáveis e praticar exercícios regularmente.";
                break;
            case 4:
                imcStatus = "Obesidade I";
                imcDescricao = "Você está com obesidade. É recomendável buscar orientação médica e nutricional para melhorar sua saúde.";
                break;
            case 5:
                imcStatus = "Obesidade II";
                imcDescricao = "Você está com obesidade. É recomendável buscar orientação médica e nutricional para melhorar sua saúde.";
                break;
            default:
                imcStatus = "Erro";
                imcDescricao = "Erro ao calcular IMC.";
                break;
        }

        if (status != null) {
            status.setText(imcStatus);
        }
        if (descricao != null) {
            descricao.setText(imcDescricao);
        }
    }

    public void limpaDados(View view) {
        TextInputEditText campoNome = findViewById(R.id.textInputNome);
        TextInputEditText campoPeso = findViewById(R.id.textInputPeso);
        TextInputEditText campoAltura = findViewById(R.id.textInputAltura);

        campoNome.setText("");
        campoPeso.setText("");
        campoAltura.setText("");

        TextView resultado1 = findViewById(R.id.textResultado1);
        resultado1.setText("");

        if (status != null) {
            status.setText("");
        }
        if (descricao != null) {
            descricao.setText("");
        }
    }
}
